import { describe, it, expect } from 'vitest';

describe('サンプルテスト', () => {
  it('1+1=2になる', () => {
    expect(1 + 1).toBe(2);
  });
}); 